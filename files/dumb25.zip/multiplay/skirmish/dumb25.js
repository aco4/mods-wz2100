//#region vscode 1.88.0+
const DEBUG=("25"=="".concat("@","{","V","E","R","S","I","O","N","}"))

const home=startPositions[me]
const center={x:mapWidth/2, y:mapHeight/2}
const players=Array(maxPlayers).fill(0).map((i,index)=>index)
const oilCount=derrickPositions.filter(i=>propulsionCanReach("wheeled01",home.x,home.y,i.x,i.y)).length
var oilRatio=oilCount/playerData.length
var structurePend=false
/**  */
var attackedByArtillery=0
//{"ANTI PERSONNEL":0, "ANTI AIRCRAFT":0, "ARTILLERY ROUND":0, "ANTI TANK":0, "FLAMER":0, "BUNKER BUSTER":0}

/** @type {_pos[]} */
const attackPath=[] //??? Avoid failure at Sk-FishNets

const FLATMAP=(derrickPositions.length/players.filter(i=>!isSpectator(i)).length)>30



const SCHEMA_MACGUN=0
const SCHEMA_CANNON=1
const SCHEMA_ROCKET=2
const SCHEMA_MORTAR=3
const SCHEMA_FLAMER=4
function chatDebug(...objs)
{
    var s=objs.map(i=>JSON.stringify(i)).join(" ")
    chat(ALL_PLAYERS,s)
    debug(gameTime+" "+playerData[me].name+": "+s)
}

//#region Argparse
const argExpr=new RegExp('(.*)-([0-9]+)?').exec(playerData[me].name)

//argExpr[0] full match
//argExpr[1] prefix name
if (argExpr!==null && argExpr[2]!==undefined)//schema
{
    var dumbSchema=parseInt(argExpr[2])
}
else
{
    var dumbSchema=SCHEMA_ROCKET
}

const _PATH="dumb25/"
include(_PATH+"EXT_DACTION.js")
include(_PATH+"libskirmish.js")

include(_PATH+"LIB.js")
include(_PATH+"LIB_STATS.js")

include(_PATH+"math/newtonMethod.js")
include(_PATH+"math/interceptPos.js")
include(_PATH+"LIB_STATS.js")
//The bot
include(_PATH+"dumbComm.js")
include(_PATH+"dumbProduction.js")
include(_PATH+"dumbResearch.js")
include(_PATH+"dumbTank.js")
include(_PATH+"dumbTruck.js")

const mainList=[dumbState,dumbProduction,dumbResearch,dumbTank,dumbTruck,dumbComm]
mainList.forEach((i,index)=>setTimer(i.name,500+index+me))

function eventChat(from, to, message="")
{
    if (to!=me)return
    if (message[0]!="!")return
    message=message.slice(1)

    if (message[0]=="s")
    {
        var i=Number(message[1])
        if (isNaN(i)) return chat(ALL_PLAYERS,`not a number:${message[1]}`)
        dumbSchema=i
        chat(ALL_PLAYERS,`schema:${i}`)
    }
}

function eventStartLevel() 
{
    if (!DEBUG)return
    debug("DEBUG")
    players.forEach(i=>{
        if (playerData[i].isHuman && !isSpectator(i))
        {
            var struct="A0ResearchFacility"
            var truck=enumDroid(i,DROID_CONSTRUCT)[0]
            var pos=pickStructLocation(truck,struct,truck.x,truck.y)
            addStructure(struct,i,pos.x*128,pos.y*128)
        }
    })
}