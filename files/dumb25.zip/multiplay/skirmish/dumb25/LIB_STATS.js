/**
 * object turret is firing or reloading
 * @param {_droid | _struct} object
 */
function objectWeaponBusy(object)
{
    return object.weapons.some(i=>
        (i.armed!=-1 && i.armed<100) ||
        ((gameTime-i.lastFired) < Stats.Weapon[i.fullname].FirePause)
    )
}

/**
 * @param {_droid | _struct} object 
 * @returns {_weaponStat}
 */
function objectWeaponStat(object)
{
    return Stats.Weapon[object.weapons[0].fullname]
}
