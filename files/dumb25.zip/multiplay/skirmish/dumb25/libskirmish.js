const _idName = {}
for (const [category, categoryData] of Object.entries(Stats)) {
    try {
        for (const [item, itemData] of Object.entries(categoryData)) {
            _idName[itemData.Id] = item
        }
    }
    catch { }
}

/**
 * TODO: Add document
 * @param {String} Id 
 * @returns {String}
 */
function idName(Id) {
    return _idName[Id]
}


/**
 * TODO: Add document
 * @param {String[]|String} body
 * @param {String[]|String} propulsion
 * @param {(String[]|String)[]} turrets
 * @returns {String}
 */
function templateName(body, propulsion, ...turrets) {
    var body0=(body instanceof Array)?body.find(i=>componentAvailable(undefined,i)):body
    var propulsion0=(propulsion instanceof Array)?propulsion.find(i=>componentAvailable(undefined,i)):propulsion
    var turret0=(turrets[0] instanceof Array)?turrets[0].find(i=>componentAvailable(undefined,i)):turrets[0]  
    var hydra=(turrets.length>1 && body0=="Body14SUP")
    return (hydra?"Hydra ":"")+(idName(turret0)+" ")+(idName(body0)+" ")+(idName(propulsion0))
}