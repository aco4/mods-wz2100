/**
 * Returns pos of interception
 * @param {_pos} target 
 * @param {_pos} attacker 
 * @param {_pos} defender 
 */
function interceptPos(target,attacker,defender)
{
    const SPEED=1.17
    const DONE=distBetween(attacker,target)/SPEED

    function attackerPos(t)
    {
        if (t<0)return attacker
        if (t>DONE)return target
        return mix([target,attacker],[t/DONE,1-t/DONE])
    }

    function f(t)
    {
        return t-distBetween(defender,attackerPos(t))/SPEED
    }

    return attackerPos(newtonMethod(f,0,5))
}
