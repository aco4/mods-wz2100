/**
 * Returns x, where f(x) < eps
 * @param {(x:Number)=>Number} f 
 * @param {Number} x0 
 * @param {number} [eps=1e-3] 
 */
function newtonMethod(f, x0, eps = 1e-3) {
    var x = x0
    for (var i = 0; i < 10; i++) {
        if (Math.abs(f(x)) < eps) break
        x -= f(x) / (f(x + 1) - f(x))
    }
    return x
}

if (typeof gameTime === 'undefined') {
    var f = x => (x - 3) ** 3
    var x0 = -1
    console.log(newtonMethod(f, x0))
}
